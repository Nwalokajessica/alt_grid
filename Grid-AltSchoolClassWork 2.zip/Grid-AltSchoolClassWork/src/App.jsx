import Grid from './Grid';

// solve the css, range utility and Grid component 

function App() {
  return (
    <Grid
      numRows={2}
      numCols={2}
    />
    
  );
}

export default App;